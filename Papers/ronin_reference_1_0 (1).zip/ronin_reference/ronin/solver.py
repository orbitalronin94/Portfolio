from .model import Solution
from .semantics import fitness, allocation, k_min, debt
from .validator import validate

def solve(system, delta=0.05):
    validate(system)
    fs=fitness(system)
    alloc=allocation(system, fs)
    km=k_min(system, delta)
    coexist=None
    return Solution(
        allocation=alloc,
        fitness=fs,
        coexistence=coexist,
        k_min=km,
        debt=debt(system),
        convergence=True,
        steps=1,
    )
