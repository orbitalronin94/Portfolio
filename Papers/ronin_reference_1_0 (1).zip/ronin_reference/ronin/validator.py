import math
from .errors import SemanticError
from .model import System

def validate(system: System, tolerance=1e-9):
    if system.parts < 2:
        raise SemanticError("parts must be >= 2")
    if len(system.agents) != system.parts:
        raise SemanticError("parts must equal the number of agents")
    if system.resource < 0 or not math.isfinite(system.resource):
        raise SemanticError("resource must be a finite non-negative number")
    for i,a in enumerate(system.agents):
        for name,v in (("phi",a.phi),("psi",a.psi),("frequency",a.frequency)):
            if not math.isfinite(v):
                raise SemanticError(f"agent {i}: {name} must be finite")
        if not 0 <= a.phi <= 1: raise SemanticError(f"agent {i}: phi outside [0,1]")
        if not 0 <= a.psi <= 1: raise SemanticError(f"agent {i}: psi outside [0,1]")
        if not 0 <= a.frequency <= 1: raise SemanticError(f"agent {i}: frequency outside [0,1]")
    p=system.params
    if not 0.5 <= p.alpha <= 2.5: raise SemanticError("alpha outside [0.5,2.5]")
    if not 0 <= p.gamma <= 1: raise SemanticError("gamma outside [0,1]")
    if not 0 <= p.sigma <= 0.5: raise SemanticError("sigma outside [0,0.5]")
    if abs(sum(a.frequency for a in system.agents)-1.0) > tolerance:
        raise SemanticError("frequencies must sum to 1 within tolerance")
    return True
