from .lexer import lex
from .errors import SyntaxError
from .model import Agent, Params, System

class Parser:
    def __init__(self, source):
        self.tokens = list(lex(source))
        self.i = 0
        self.systems = {}

    @property
    def t(self):
        return self.tokens[self.i]

    def take(self):
        t = self.t
        self.i += 1
        return t

    def accept(self, value):
        if self.t.value == value:
            return self.take()
        return None

    def expect(self, value):
        t = self.take()
        if t.value != value:
            raise SyntaxError(f"Expected {value!r} at {t.line}:{t.column}, got {t.value!r}")
        return t

    def ident(self):
        t = self.take()
        if t.kind != "IDENT":
            raise SyntaxError(f"Expected identifier at {t.line}:{t.column}")
        return t.value

    def number(self):
        t = self.take()
        if t.kind != "NUMBER":
            raise SyntaxError(f"Expected number at {t.line}:{t.column}")
        return float(t.value)

    def value(self):
        if self.t.kind == "NUMBER":
            return self.number()
        if self.t.kind == "IDENT":
            v=self.take().value
            if v in ("true","false"):
                return v == "true"
            return v
        raise SyntaxError(f"Expected value at {self.t.line}:{self.t.column}")

    def field(self):
        k=self.ident()
        self.expect(":")
        v=self.value()
        self.accept(",")
        return k,v

    def agent(self):
        self.expect("{")
        d={}
        while self.t.value != "}":
            k,v=self.field(); d[k]=v
        self.expect("}")
        self.accept(",")
        try:
            return Agent(float(d["phi"]), float(d["psi"]), float(d["frequency"]))
        except KeyError as e:
            raise SyntaxError(f"Missing agent field: {e.args[0]}")

    def agents(self):
        self.expect("[")
        out=[]
        while self.t.value != "]":
            out.append(self.agent())
        self.expect("]")
        self.accept(",")
        return out

    def params(self):
        self.expect("{")
        d={}
        while self.t.value != "}":
            k,v=self.field(); d[k]=v
        self.expect("}")
        self.accept(",")
        return Params(alpha=float(d.get("alpha",1.0)),
                      gamma=float(d.get("gamma",0.4)),
                      sigma=float(d.get("sigma",0.0)))

    def system(self):
        self.expect("system")
        name=self.ident()
        self.expect("="); self.expect("{")
        fields={}
        while self.t.value != "}":
            k=self.ident()
            self.expect(":")
            if k=="agents":
                fields[k]=self.agents()
            elif k=="params":
                fields[k]=self.params()
            else:
                fields[k]=self.value()
                self.accept(",")
        self.expect("}")
        s=System(name, int(fields["parts"]), float(fields["resource"]),
                 fields["agents"], fields.get("params", Params()))
        self.systems[name]=s
        return s

    def program(self):
        while self.t.kind != "EOF":
            if self.t.value == "system":
                self.system()
            else:
                # Reference parser accepts commands but leaves execution to CLI.
                self.take()
        return self.systems

def parse(source):
    return Parser(source).program()
