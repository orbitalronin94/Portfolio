from dataclasses import dataclass
import re
from .errors import SyntaxError

@dataclass(frozen=True)
class Token:
    kind: str
    value: str
    line: int
    column: int

_TOKEN_RE = re.compile(
    r"""
    (?P<WS>[ \t\r\n]+)
  | (?P<COMMENT>//[^\n]*)
  | (?P<NUMBER>(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)
  | (?P<IDENT>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<SYMBOL>[{}\[\](),:=])
    """, re.X)

def lex(source: str):
    pos = 0
    line = 1
    col = 1
    while pos < len(source):
        m = _TOKEN_RE.match(source, pos)
        if not m:
            raise SyntaxError(f"Unexpected character at {line}:{col}: {source[pos]!r}")
        raw = m.group(0)
        kind = m.lastgroup
        if kind not in ("WS", "COMMENT"):
            yield Token(kind, raw, line, col)
        nl = raw.count("\n")
        if nl:
            line += nl
            col = len(raw.rsplit("\n", 1)[1]) + 1
        else:
            col += len(raw)
        pos = m.end()
    yield Token("EOF", "", line, col)
