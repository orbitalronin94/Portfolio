import argparse, json, sys
from . import __version__
from .parser import parse
from .validator import validate
from .solver import solve
from .simulator import simulate
from .errors import RoninError

def main(argv=None):
    ap=argparse.ArgumentParser(prog="ronin")
    ap.add_argument("--version", action="version", version=f"RONIN {__version__}")
    sub=ap.add_subparsers(dest="cmd", required=True)
    for name in ("check","solve"):
        p=sub.add_parser(name); p.add_argument("file")
    p=sub.add_parser("simulate"); p.add_argument("file"); p.add_argument("--steps",type=int,default=100); p.add_argument("--seed",type=int)
    ns=ap.parse_args(argv)
    try:
        systems=parse(open(ns.file,encoding="utf-8").read())
        if not systems: raise RoninError("no system declaration found")
        system=next(iter(systems.values()))
        if ns.cmd=="check":
            validate(system); print("OK"); return 0
        if ns.cmd=="solve":
            s=solve(system)
            print(json.dumps(s.__dict__, indent=2))
            return 0
        s=simulate(system, ns.steps, ns.seed)
        print(json.dumps(s.__dict__, indent=2))
        return 0
    except RoninError as e:
        print(f"RONIN ERROR: {e}", file=sys.stderr)
        return getattr(e,"code",3)
    except Exception as e:
        print(f"RONIN ERROR: {e}", file=sys.stderr)
        return 3

if __name__=="__main__":
    raise SystemExit(main())
