from dataclasses import dataclass, field
from typing import List, Optional

@dataclass(frozen=True)
class Agent:
    phi: float
    psi: float
    frequency: float

@dataclass(frozen=True)
class Params:
    alpha: float = 1.0
    gamma: float = 0.4
    sigma: float = 0.0

@dataclass(frozen=True)
class System:
    name: str
    parts: int
    resource: float
    agents: List[Agent]
    params: Params

@dataclass
class Solution:
    allocation: List[float]
    fitness: List[float]
    coexistence: Optional[bool]
    k_min: Optional[float]
    debt: float
    convergence: bool = True
    steps: int = 1

@dataclass
class Simulation:
    history: List[List[float]]
    final_state: List[float]
    steps: int
    seed: Optional[int]
    extinction_events: List[int] = field(default_factory=list)
    survivability: float = 1.0
