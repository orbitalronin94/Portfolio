import random
from .model import Simulation
from .validator import validate
from .semantics import fitness

def _project_simplex(values):
    vals=[max(0.0,x) for x in values]
    s=sum(vals)
    if s == 0:
        return [1.0/len(vals)]*len(vals)
    return [x/s for x in vals]

def simulate(system, steps=100, seed=None):
    """
    Reference-runtime stochastic extension.

    The specification defines simulate as stochastic but does not prescribe a
    unique transition kernel. This implementation therefore uses an explicit,
    documented kernel: fitness-proportional drift plus Gaussian noise, followed
    by projection onto the probability simplex. It is implementation-defined,
    while solve remains fully normative.
    """
    validate(system)
    if steps < 1:
        raise ValueError("steps must be >= 1")
    rng=random.Random(seed)
    state=[a.frequency for a in system.agents]
    history=[state.copy()]
    extinct=[]
    alpha=system.params.alpha
    sigma=system.params.sigma
    for step in range(steps):
        weights=[a.phi*a.psi*(max(x,0.0)**alpha) for a,x in zip(system.agents,state)]
        total=sum(weights)
        target=[w/total for w in weights] if total else [1.0/len(state)]*len(state)
        # Relaxation toward fitness equilibrium; sigma controls stochastic perturbation.
        proposal=[x + 0.5*(t-x) + rng.gauss(0.0,sigma/10.0) for x,t in zip(state,target)]
        state=_project_simplex(proposal)
        extinct.extend(i for i,x in enumerate(state) if x <= 1e-12 and i not in extinct)
        history.append(state.copy())
    survivability=sum(1 for x in state if x > 1e-12)/len(state)
    return Simulation(history, state, steps, seed, extinct, survivability)
