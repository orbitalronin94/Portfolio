import math
from .errors import SemanticError
from .validator import validate

def fitness(system):
    validate(system)
    a=system.params.alpha
    out=[]
    for agent in system.agents:
        # RONIN 1.0 base: epsilon_i = 1
        out.append(agent.phi * agent.psi * (agent.frequency ** a))
    return out

def allocation(system, fs=None):
    fs = fitness(system) if fs is None else fs
    total=sum(fs)
    if system.resource == 0:
        return [0.0]*len(fs)
    if total <= 0:
        raise SemanticError("allocation undefined: sum of fitness is zero")
    return [system.resource*f/total for f in fs]

def k_min(system, delta=0.05):
    products=[a.phi*a.psi for a in system.agents]
    if min(products) <= 0:
        return None
    s=system.parts
    if delta <= 0 or s/delta <= 1:
        raise SemanticError("invalid coexistence delta")
    return s*(max(products)/min(products))/math.log(s/delta)

def debt(system):
    # v1.0 base audit: debt is the resource not assigned only by numerical residual.
    # Since allocation is normalized, the semantic debt is zero.
    return 0.0
