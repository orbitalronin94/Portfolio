import unittest
from ronin.parser import parse
from ronin.solver import solve
from ronin.validator import validate
from ronin.simulator import simulate
from ronin.errors import SemanticError

MAQ = open("examples/maquinas.ronin", encoding="utf-8").read()
PES = open("examples/pesca.ronin", encoding="utf-8").read()

class CoreTests(unittest.TestCase):
    def test_parser(self):
        s=parse(MAQ)["Maquinas"]
        self.assertEqual(s.parts,2)
        self.assertEqual(len(s.agents),2)

    def test_solve_maquinas(self):
        s=solve(parse(MAQ)["Maquinas"])
        self.assertAlmostEqual(s.fitness[0],0.48)
        self.assertAlmostEqual(s.fitness[1],0.20)
        self.assertAlmostEqual(s.allocation[0],70.58823529411765)
        self.assertAlmostEqual(s.allocation[1],29.411764705882355)
        self.assertAlmostEqual(sum(s.allocation),100.0)

    def test_pesca_frequency_sum(self):
        s=parse(PES)["Pesca"]
        validate(s)
        self.assertAlmostEqual(sum(a.frequency for a in s.agents),1.0)

    def test_invalid_frequency(self):
        src=MAQ.replace("frequency: 0.4","frequency: 0.3")
        with self.assertRaises(SemanticError):
            validate(parse(src)["Maquinas"])

    def test_zero_resource(self):
        s=parse(MAQ)["Maquinas"]
        from dataclasses import replace
        s=replace(s, resource=0)
        r=solve(s)
        self.assertEqual(r.allocation,[0.0,0.0])

    def test_simulation_seed(self):
        s=parse(MAQ)["Maquinas"]
        a=simulate(s,steps=10,seed=42)
        b=simulate(s,steps=10,seed=42)
        self.assertEqual(a.history,b.history)
        self.assertEqual(a.final_state,b.final_state)

if __name__=="__main__":
    unittest.main()
